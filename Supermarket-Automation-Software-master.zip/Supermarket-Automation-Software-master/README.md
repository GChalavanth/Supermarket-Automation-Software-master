# Supermarket Automation Software

Built for Software Engineering course (Spring 2013)

By Siddharth Rakesh and Sachin Kumar


















